import { defineConfig } from "allure";

export default defineConfig({
  name: "旅平險服務 自動化測試報告",
  output: "./allure-report",
  historyPath: "./allure-history.jsonl",        // 每次產生報告都會把結果累積到這個檔案
  hideLabels: ["host", "thread", "language", "framework", "package"],   // 不顯示電腦名稱等內部資訊
  categories: [
    { name: "產品缺陷：保費計算", matchers: { statuses: ["failed"], message: /保費/ } },
    { name: "環境問題：連線或逾時", matchers: { statuses: ["broken"], message: /Timeout|ConnectionError/ } },
    { name: "測試程式的問題", matchers: { statuses: ["broken"] } },
  ],
  plugins: {
    awesome: {
      options: { singleFile: true, reportLanguage: "zh-TW", groupBy: ["epic", "feature", "story"] },
    },
  },
});
