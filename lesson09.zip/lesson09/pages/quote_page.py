import allure
from playwright.sync_api import Page


class QuotePage:
    URL = "/quote"

    def __init__(self, page: Page):
        self.page = page
        self.age = page.get_by_label("年齡")
        self.days = page.get_by_label("天數")
        self.plan = page.get_by_label("方案")
        self.addon = page.get_by_label("加購不便險")
        self.calc_button = page.get_by_role("button", name="試算")
        self.result = page.get_by_role("status")
        self.error = page.get_by_role("alert")

    @allure.step("開啟保費試算頁")
    def open(self):
        self.page.goto(self.URL)
        return self

    @allure.step("試算：{age} 歲、{days} 天、方案 {plan}、不便險 {addon}")
    def calculate(self, age, days, plan="基本型", addon=False):
        self.age.fill(str(age))
        self.days.fill(str(days))
        self.plan.select_option(plan)
        self.addon.set_checked(addon)
        self.calc_button.click()
