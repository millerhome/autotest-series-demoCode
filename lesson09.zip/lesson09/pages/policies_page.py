import allure
from playwright.sync_api import Page, expect


class PoliciesPage:
    URL = "/policies"

    def __init__(self, page: Page):
        self.page = page
        self.holder = page.get_by_label("要保人")
        self.age = page.get_by_label("年齡")
        self.days = page.get_by_label("天數")
        self.add_button = page.get_by_role("button", name="新增保單")
        self.rows = page.get_by_role("row")

    @allure.step("開啟保單管理頁")
    def open(self):
        self.page.goto(self.URL)
        return self

    def row(self, text):
        return self.rows.filter(has_text=text)

    @allure.step("新增保單：{holder}、{age} 歲、{days} 天")
    def add(self, holder, age, days):
        self.holder.fill(holder)
        self.age.fill(str(age))
        self.days.fill(str(days))
        self.add_button.click()
        expect(self.row(holder)).to_be_visible()

    @allure.step("註銷保單 {policy_no}")
    def cancel(self, policy_no):
        self.page.once("dialog", lambda dialog: dialog.accept())
        self.page.get_by_role("button", name=f"註銷 {policy_no}").click()
        expect(self.row(policy_no)).to_contain_text("已註銷")
