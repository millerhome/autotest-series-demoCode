import allure
import pytest
from playwright.sync_api import expect

from pages.policies_page import PoliciesPage
from pages.quote_page import QuotePage

pytestmark = [pytest.mark.ui, allure.label("layer", "UI")]


@allure.epic("保費試算")
@allure.feature("試算畫面")
@allure.story("基本型")
@allure.title("畫面試算：30 歲、5 天顯示 150 元")
@allure.severity(allure.severity_level.CRITICAL)
@pytest.mark.smoke
def test_ui_quote(quote_page: QuotePage):
    quote_page.calculate(age=30, days=5)

    with allure.step("驗證畫面顯示的保費"):
        expect(quote_page.result).to_have_text("保費 150 元")


@allure.epic("保費試算")
@allure.feature("試算畫面")
@allure.story("豪華型")
@allure.title("畫面試算：豪華型加不便險顯示 275 元")
@allure.issue("4721", "豪華型保費係數")
def test_ui_quote_plus(quote_page: QuotePage):
    quote_page.calculate(age=30, days=5, plan="豪華型", addon=True)

    with allure.step("驗證畫面顯示的保費"):
        expect(quote_page.result).to_have_text("保費 275 元", timeout=3000)


@allure.epic("保單管理")
@allure.feature("保單畫面")
@allure.story("新增與註銷")
@allure.title("畫面新增保單後可以註銷")
@allure.severity(allure.severity_level.CRITICAL)
@pytest.mark.smoke
def test_ui_add_and_cancel(policies_page: PoliciesPage, holder):
    policies_page.add(holder, age=30, days=5)
    policy_no = policies_page.row(holder).get_by_role("cell").first.inner_text()

    policies_page.cancel(policy_no)

    with allure.step("驗證註銷後沒有註銷按鈕"):
        expect(policies_page.row(policy_no).get_by_role("button")).to_have_count(0)
