import json
import platform
import threading
import uuid
from pathlib import Path

import allure
import pytest
import requests
from playwright.sync_api import Page, expect

from pages.policies_page import PoliciesPage
from pages.quote_page import QuotePage
from policy_web import make_server


@pytest.fixture(scope="session")
def base_url():
    server = make_server()
    threading.Thread(target=server.serve_forever, daemon=True).start()
    yield f"http://127.0.0.1:{server.server_port}"
    server.shutdown()


@pytest.fixture(scope="session", autouse=True)
def allure_environment(request, base_url):
    """把這次執行的環境資訊寫進報告。"""
    results_dir = request.config.getoption("--alluredir")
    if results_dir:
        lines = [f"受測環境=本機練習網站", f"Python={platform.python_version()}",
                 f"作業系統={platform.system()} {platform.release()}", "瀏覽器=Chrome（channel）"]
        Path(results_dir, "environment.properties").write_text("\n".join(lines), encoding="utf-8")


class Api:
    """會把每一次請求與回應附到報告裡的 API client。"""

    def __init__(self, base_url):
        self.base_url = base_url
        self.session = requests.Session()

    def request(self, method, path, **kwargs):
        kwargs.setdefault("timeout", 5)
        with allure.step(f"{method} {path}"):
            r = self.session.request(method, self.base_url + path, **kwargs)
            sent = kwargs.get("json") or kwargs.get("params")
            if sent:
                allure.attach(json.dumps(sent, ensure_ascii=False, indent=2), "請求內容",
                              allure.attachment_type.JSON)
            if r.headers.get("Content-Type", "").startswith("application/json"):
                allure.attach(json.dumps(r.json(), ensure_ascii=False, indent=2), f"回應 {r.status_code}",
                              allure.attachment_type.JSON)
            return r


@pytest.fixture(scope="session")
def api(base_url):
    client = Api(base_url)
    r = client.session.post(base_url + "/login", data={"username": "tester", "password": "test-pass-123"},
                            timeout=5)
    assert "/quote" in r.url, "登入失敗"
    return client


@pytest.fixture
def holder():
    return f"測試_{uuid.uuid4().hex[:6]}"


@pytest.fixture
def login(page: Page):
    with allure.step("登入"):
        page.goto("/login")
        page.get_by_label("帳號").fill("tester")
        page.get_by_label("密碼").fill("test-pass-123")
        page.get_by_role("button", name="登入").click()
        expect(page.get_by_role("heading", name="保費試算")).to_be_visible()
    return page


@pytest.fixture
def quote_page(login: Page) -> QuotePage:
    return QuotePage(login).open()


@pytest.fixture
def policies_page(login: Page) -> PoliciesPage:
    return PoliciesPage(login).open()


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    """UI 測試失敗時，把當下的畫面截圖附到報告裡。"""
    outcome = yield
    report = outcome.get_result()
    if report.when == "call" and report.failed and "page" in item.funcargs:
        page = item.funcargs["page"]
        allure.attach(page.screenshot(full_page=True), "失敗時的畫面", allure.attachment_type.PNG)
        allure.attach(page.url, "失敗時的網址", allure.attachment_type.TEXT)
