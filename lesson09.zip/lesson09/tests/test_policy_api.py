import os

import allure
import pytest

pytestmark = [allure.epic("保單管理"), allure.feature("保單 API")]


@allure.story("新增與註銷")
@allure.title("保單生命週期：新增、查得到、註銷")
@allure.severity(allure.severity_level.BLOCKER)
@allure.description("對應過版檢查表第 3 項：投保與註銷流程。")
@pytest.mark.regression
def test_policy_lifecycle(api, holder):
    with allure.step("新增保單"):
        r = api.request("POST", "/api/policies", json={"holder": holder, "age": 70, "days": 10})
        assert r.status_code == 201
        policy = r.json()
        assert policy["premium"] == 450

    with allure.step("清單裡查得到"):
        items = api.request("GET", "/api/policies").json()["items"]
        assert policy["no"] in [p["no"] for p in items]

    with allure.step("註銷"):
        r = api.request("POST", f"/api/policies/{policy['no']}/cancel")
        assert r.json()["status"] == "cancelled"


@allure.story("輸入檢核")
@allure.title("要保人空白時拒絕新增")
def test_create_requires_holder(api):
    r = api.request("POST", "/api/policies", json={"holder": "", "age": 30, "days": 5})

    assert r.status_code == 422
    assert r.json()["error"] == "要保人姓名不可空白"


@allure.story("新增與註銷")
@allure.title("回應包含建立時間")
@pytest.mark.skip(reason="功能尚未開發：預計下一版加入 created_at 欄位")
def test_created_at_in_response(api, holder):
    r = api.request("POST", "/api/policies", json={"holder": holder, "age": 30, "days": 5})
    assert "created_at" in r.json()


@allure.story("新增與註銷")
@allure.title("新增後回傳保單號碼")
def test_create_returns_policy_no(api, holder):
    r = api.request("POST", "/api/policies", json={"holder": holder, "age": 30, "days": 5})

    key = "policy_no" if os.environ.get("DEMO_BROKEN") == "1" else "no"     # 示範用：測試程式寫錯欄位名稱
    assert r.json()[key].startswith("TP")
