import allure
import pytest

pytestmark = [allure.epic("保費試算"), allure.feature("試算 API")]


@allure.story("基本型")
@allure.title("成年人 30 歲、5 天，保費 150 元")
@allure.severity(allure.severity_level.BLOCKER)
@pytest.mark.smoke
def test_quote_adult(api):
    r = api.request("GET", "/api/quote", params={"age": 30, "days": 5})

    with allure.step("驗證狀態碼與保費"):
        assert r.status_code == 200
        assert r.json()["premium"] == 150


@allure.story("基本型")
@allure.severity(allure.severity_level.CRITICAL)
@pytest.mark.parametrize("age, expected", [
    pytest.param(0, 120, id="0歲-承保下限"),
    pytest.param(17, 120, id="17歲-未成年上限"),
    pytest.param(18, 150, id="18歲-成年下限"),
    pytest.param(64, 150, id="64歲-成年上限"),
    pytest.param(65, 225, id="65歲-高齡下限"),
    pytest.param(80, 225, id="80歲-承保上限"),
])
def test_quote_age_bands(api, age, expected):
    allure.dynamic.title(f"年齡 {age} 歲、5 天，保費 {expected} 元")

    r = api.request("GET", "/api/quote", params={"age": age, "days": 5})

    assert r.json()["premium"] == expected, f"保費不符：{age} 歲預期 {expected}，實際 {r.json()['premium']}"


@allure.story("豪華型")
@allure.title("豪華型是基本型的 1.5 倍")
@allure.severity(allure.severity_level.CRITICAL)
@allure.issue("4721", "豪華型保費係數")
@pytest.mark.parametrize("age, days, expected", [(30, 5, 225), (70, 10, 675)])
def test_quote_plus_plan(api, age, days, expected):
    r = api.request("GET", "/api/quote", params={"age": age, "days": days, "plan": "plus"})

    assert r.json()["premium"] == expected, f"保費不符：預期 {expected}，實際 {r.json()['premium']}"


@allure.story("輸入檢核")
@allure.severity(allure.severity_level.NORMAL)
@pytest.mark.parametrize("params, message", [
    pytest.param({"age": 81, "days": 5}, "年齡不在承保範圍", id="超過承保上限"),
    pytest.param({"age": 30, "days": 0}, "天數至少 1 天", id="天數為零"),
])
def test_quote_rejects_invalid(api, params, message):
    r = api.request("GET", "/api/quote", params=params)

    assert r.status_code == 422
    assert r.json()["error"] == message
