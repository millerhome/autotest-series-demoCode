"""過版測試的執行腳本：過版前回歸（pre）與過版後冒煙（post）。

用法：python run_tests.py pre --env sit
      python run_tests.py post --env prod
結束代碼：0 全部通過　1 有測試沒通過　2 環境或設定有問題，測試沒有執行
"""
import argparse
import logging
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path

import requests

from settings import ConfigError, load_settings

ROOT = Path(__file__).parent
STAGES = {"pre": ("過版前回歸", "smoke or regression"), "post": ("過版後冒煙", "smoke")}
log = logging.getLogger("run_tests")


def preflight(settings, retries=3, wait=2):
    """開始之前先確認受測系統活著，並取得版本。連不上就不要浪費時間跑測試。"""
    for attempt in range(1, retries + 1):
        try:
            r = requests.get(settings.base_url + "/api/health", timeout=5)
            if r.status_code == 200:
                return r.json().get("version", "未知")
            log.warning("健康檢查回應 %s（第 %s 次）", r.status_code, attempt)
        except requests.RequestException as e:
            log.warning("連不上受測系統（第 %s 次）：%s", attempt, type(e).__name__)
        time.sleep(wait)
    return None


def summarize(junit_file):
    suite = ET.parse(junit_file).getroot().find("testsuite")
    total, failures, errors, skipped = (int(suite.get(k, 0)) for k in ("tests", "failures", "errors", "skipped"))
    return {"total": total, "failed": failures + errors, "skipped": skipped,
            "passed": total - failures - errors - skipped, "seconds": float(suite.get("time", 0))}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=STAGES)
    parser.add_argument("--env", required=True)
    parser.add_argument("--timeout", type=int, default=1800, help="整輪測試最多執行幾秒")
    args = parser.parse_args()
    stage_name, markers = STAGES[args.stage]

    try:
        settings = load_settings(args.env)
    except ConfigError as e:
        print(f"設定有問題：{e}", file=sys.stderr)
        return 2

    run_dir = ROOT / "runs" / f"{datetime.now():%Y%m%d_%H%M%S}_{args.env}_{args.stage}"
    run_dir.mkdir(parents=True)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                        handlers=[logging.FileHandler(run_dir / "run.log", encoding="utf-8"),
                                  logging.StreamHandler()])
    if settings.only_markers:                       # 環境本身限制能跑的範圍（例如正式環境）
        markers = f"({markers}) and ({settings.only_markers})"
    log.info("%s｜環境：%s｜%s", stage_name, settings.name, settings.base_url)

    version = preflight(settings)
    if version is None:
        log.error("受測系統沒有回應，測試沒有執行")
        return 2
    log.info("受測系統版本：%s", version)

    cmd = [sys.executable, "-m", "pytest", "--env", args.env, "-m", markers, "-q",
           "-n", str(settings.workers), "--junitxml", str(run_dir / "junit.xml"),
           "--alluredir", str(run_dir / "allure-results")]
    log.info("執行：pytest -m \"%s\" -n %s", markers, settings.workers)
    try:
        result = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=args.timeout)
    except subprocess.TimeoutExpired:
        log.error("超過 %s 秒還沒跑完，已強制結束", args.timeout)
        return 2
    (run_dir / "pytest-output.txt").write_text(result.stdout + result.stderr, encoding="utf-8")
    if result.returncode not in (0, 1):
        log.error("pytest 沒有正常執行（結束代碼 %s），請看 pytest-output.txt", result.returncode)
        return 2

    s = summarize(run_dir / "junit.xml")
    verdict = "通過" if result.returncode == 0 else "未通過"
    line = (f"[{verdict}] {stage_name}｜{settings.name}｜版本 {version}｜"
            f"共 {s['total']}、通過 {s['passed']}、失敗 {s['failed']}、跳過 {s['skipped']}｜{s['seconds']:.1f} 秒")
    (run_dir / "summary.txt").write_text(line + "\n", encoding="utf-8")
    log.info(line)

    if shutil.which("npx") and (ROOT / "allurerc.mjs").exists():      # 有安裝 Allure 才產生報告
        subprocess.run(["npx", "allure", "generate", str(run_dir / "allure-results"), "-o", str(run_dir / "report")],
                       cwd=ROOT, capture_output=True, text=True)
    log.info("結果資料夾：%s", run_dir.relative_to(ROOT))
    return result.returncode


if __name__ == "__main__":
    sys.exit(main())
