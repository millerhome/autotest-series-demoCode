import requests


class WriteNotAllowed(RuntimeError):
    """這個環境不允許異動資料。"""


class ApiClient:
    def __init__(self, base_url, allow_write, timeout=5):
        self.base_url = base_url
        self.allow_write = allow_write
        self.timeout = timeout
        self.session = requests.Session()

    def request(self, method, path, **kwargs):
        # 第二道防線：就算測試被誤選進來，唯讀環境也送不出會異動資料的請求
        if not self.allow_write and method.upper() != "GET" and path != "/api/login":
            raise WriteNotAllowed(f"這個環境是唯讀的，拒絕送出 {method} {path}")
        kwargs.setdefault("timeout", self.timeout)
        return self.session.request(method, self.base_url + path, **kwargs)

    def login(self, username, password):
        r = self.request("POST", "/api/login", json={"username": username, "password": password})
        assert r.status_code == 200, f"登入失敗：{r.status_code}"          # 不印出回應內容與密碼
        self.session.headers["Authorization"] = f"Bearer {r.json()['token']}"
