import pytest


@pytest.mark.smoke
@pytest.mark.readonly
def test_login_and_list(api):
    r = api.request("GET", "/api/policies")
    assert r.status_code == 200
    assert "items" in r.json()


@pytest.mark.readonly
@pytest.mark.regression
def test_list_requires_token(anon):
    r = anon.request("GET", "/api/policies")
    assert r.status_code == 401


@pytest.mark.writes
@pytest.mark.regression
def test_create_policy(api, holder):
    r = api.request("POST", "/api/policies", json={"holder": holder, "age": 30, "days": 5})
    assert r.status_code == 201
    assert r.json()["premium"] == 150
    api.request("DELETE", f"/api/policies/{r.json()['no']}")


@pytest.mark.writes
@pytest.mark.regression
def test_read_policy(api, policy):
    r = api.request("GET", f"/api/policies/{policy['no']}")
    assert r.json() == policy


@pytest.mark.writes
@pytest.mark.regression
def test_search_own_policy(api, policy, holder):
    r = api.request("GET", "/api/policies", params={"holder": holder})
    assert r.json()["total"] == 1                    # 姓名是這支測試專用的，所以可以驗證確切的筆數


@pytest.mark.writes
@pytest.mark.regression
def test_delete_policy(api, policy):
    assert api.request("DELETE", f"/api/policies/{policy['no']}").status_code == 204
    assert api.request("GET", f"/api/policies/{policy['no']}").status_code == 404


@pytest.mark.writes
@pytest.mark.regression
@pytest.mark.parametrize("body", [{"holder": "", "age": 30, "days": 5}, {"holder": "王小明", "age": 81, "days": 5},
                                  {"holder": "王小明", "age": 30, "days": 0}, {"age": 30, "days": 5}])
def test_create_rejects_invalid(api, body):
    r = api.request("POST", "/api/policies", json=body)
    assert r.status_code == 422
