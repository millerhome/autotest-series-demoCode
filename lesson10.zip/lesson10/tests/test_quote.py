import pytest

pytestmark = pytest.mark.readonly


@pytest.mark.smoke
def test_health(anon):
    r = anon.request("GET", "/api/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


@pytest.mark.smoke
def test_quote_adult(anon):
    r = anon.request("GET", "/api/quote", params={"age": 30, "days": 5})
    assert r.json() == {"premium": 150, "currency": "TWD"}


@pytest.mark.regression
@pytest.mark.parametrize("age, days, expected", [
    (0, 5, 120), (17, 5, 120), (18, 5, 150), (64, 5, 150), (65, 5, 225), (80, 5, 225),
    (30, 1, 30), (30, 30, 900), (70, 10, 450), (10, 3, 72),
])
def test_quote_table(anon, age, days, expected):
    r = anon.request("GET", "/api/quote", params={"age": age, "days": days})
    assert r.json()["premium"] == expected, f"保費不符：預期 {expected}，實際 {r.json().get('premium')}"


@pytest.mark.regression
@pytest.mark.parametrize("params", [{"age": 81, "days": 5}, {"age": -1, "days": 5},
                                    {"age": 30, "days": 0}, {"days": 5}])
def test_quote_rejects_invalid(anon, params):
    r = anon.request("GET", "/api/quote", params=params)
    assert r.status_code == 422
