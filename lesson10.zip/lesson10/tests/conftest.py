import uuid

import pytest

from api_client import ApiClient
from settings import ConfigError, load_settings


def pytest_addoption(parser):
    parser.addoption("--env", default=None, help="要執行測試的環境（登記在 environments.toml）")


def pytest_configure(config):
    """一開始就讀取設定：環境沒有登記、缺少帳密，就直接停止，一支測試都不跑。"""
    try:
        config.settings = load_settings(config.getoption("--env"))
    except ConfigError as e:
        pytest.exit(f"拒絕執行：{e}", returncode=2)


def pytest_collection_modifyitems(config, items):
    """第一道防線：唯讀的環境，把會異動資料的測試全部排除。"""
    if config.settings.allow_write:
        return
    keep, drop = [], []
    for item in items:
        (drop if item.get_closest_marker("writes") or not item.get_closest_marker("readonly") else keep).append(item)
    if drop:
        config.hook.pytest_deselected(items=drop)
        items[:] = keep


def pytest_report_header(config):
    s = config.settings
    return f"受測環境：{s.name}（{s.env}）　{s.base_url}　可異動資料：{'是' if s.allow_write else '否'}"


@pytest.fixture(scope="session")
def settings(request):
    return request.config.settings


@pytest.fixture(scope="session")
def anon(settings):
    return ApiClient(settings.base_url, settings.allow_write)


@pytest.fixture(scope="session")
def api(settings):
    client = ApiClient(settings.base_url, settings.allow_write)
    client.login(settings.username, settings.password)
    return client


@pytest.fixture
def holder(worker_id):
    """每支測試專用的要保人姓名；帶上 worker 編號，平行執行時不會互相干擾。"""
    return f"測試_{worker_id}_{uuid.uuid4().hex[:6]}"


@pytest.fixture
def policy(api, holder):
    r = api.request("POST", "/api/policies", json={"holder": holder, "age": 30, "days": 5})
    assert r.status_code == 201, r.text
    yield r.json()
    api.request("DELETE", f"/api/policies/{r.json()['no']}")
