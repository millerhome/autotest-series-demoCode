import pytest


@pytest.mark.writes
@pytest.mark.parametrize("n", range(4))
def test_shared_holder_name(api, n):
    """四支測試都用同一個要保人姓名：循序執行沒問題，平行執行就會互相干擾。"""
    r = api.request("POST", "/api/policies", json={"holder": "共用的王小明", "age": 30, "days": 5})
    no = r.json()["no"]
    try:
        found = api.request("GET", "/api/policies", params={"holder": "共用的王小明"}).json()
        assert found["total"] == 1, f"預期只有自己建立的 1 筆，實際 {found['total']} 筆"
    finally:
        api.request("DELETE", f"/api/policies/{no}")


@pytest.mark.readonly
def test_marked_readonly_but_writes(api):
    """標成 readonly，卻偷偷送出 POST：唯讀環境的 client 會擋下來。"""
    api.request("POST", "/api/policies", json={"holder": "不該出現", "age": 30, "days": 5})
