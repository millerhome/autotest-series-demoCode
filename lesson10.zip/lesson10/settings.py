"""讀取環境設定與機密。所有「測試要打哪裡、能做什麼」的判斷都集中在這裡。"""
import os
import tomllib
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

CONFIG_FILE = Path(__file__).parent / "environments.toml"


class ConfigError(Exception):
    """設定有問題：測試不應該開始執行。"""


@dataclass(frozen=True)
class Settings:
    env: str
    name: str
    base_url: str
    allow_write: bool
    workers: int
    only_markers: str | None
    username: str
    password: str

    @property
    def host(self):
        return urlparse(self.base_url).hostname

    def __repr__(self):                      # 印出設定時，不會把密碼印出來
        return (f"Settings(env={self.env!r}, base_url={self.base_url!r}, "
                f"allow_write={self.allow_write}, username={self.username!r}, password='***')")


def load_settings(env: str | None = None) -> Settings:
    env = env or os.environ.get("TEST_ENV")
    if not env:
        raise ConfigError("沒有指定環境：請用 --env 或環境變數 TEST_ENV 指定（例如 sit）")
    table = tomllib.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    if env not in table:
        raise ConfigError(f"環境 {env!r} 沒有登記在 environments.toml，可用的環境：{', '.join(table)}")
    cfg = table[env]

    prefix = f"TEST_{env.upper()}_"          # 例如 TEST_SIT_USER、TEST_SIT_PASSWORD
    username = os.environ.get(prefix + "USER")
    password = os.environ.get(prefix + "PASSWORD")
    if not username or not password:
        raise ConfigError(f"找不到帳號或密碼：請設定環境變數 {prefix}USER 與 {prefix}PASSWORD")

    return Settings(env=env, name=cfg["name"], base_url=cfg["base_url"].rstrip("/"),
                    allow_write=cfg["allow_write"], workers=cfg.get("workers", 1),
                    only_markers=cfg.get("only_markers"), username=username, password=password)
